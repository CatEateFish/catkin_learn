topic name: /cmd_vel_head

w: linear.x + 1
x: linear.x - 1
a: angular.z + 1
d: angular.z - 1
1~4: linear.z 输出 1~4

linear.x取值范围: -90～90
angular.z取值范围: -90~90 
